<?php
//Routing:dieu huong
//Kiem tra URL cua nguoi dung> Tim ra Controller
//URL:tlu.edu.vn/ = tlu.edu.vn/index.php?route=home > HomeController
//URL:tlu.edu.vn/index.php?route=article > ArticleController

$route = isset( $_GET['route'])?$_GET['route']:'home';
 

if($route == 'home'){
    echo "HomeController";
}elseif ($route=='articles'){
    echo "ArticleController";
}else{
    echo "Other";
}






?>