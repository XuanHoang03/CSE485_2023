<?php
require_once 'services/ArticleService.php';

class HomeController {
    private $articleService;

    public function __construct() {
        $this->articleService = new ArticleService();
    }

    public function index() {
        // Xử lý yêu cầu để hiển thị trang chủ
        $articles = $this->articleService->getAllArticles();
        $this->renderView('home', ['articles' => $articles]);
        // ...
    }

    private function renderView($view, $data) {
        // Trích xuất dữ liệu từ mảng thành các biến
        extract($data);

        // Gọi tệp view tương ứng
        include($view . '.php');
    }
}
?>
