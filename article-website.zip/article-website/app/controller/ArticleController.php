<?php
require_once 'services/ArticleService.php';

class ArticleController {
    private $articleService;

    public function __construct() {
        $this->articleService = new ArticleService();
    }

    public function add() {
        // Xử lý yêu cầu để thêm một bài viết mới
    }

    public function edit($id) {
        // Xử lý yêu cầu để chỉnh sửa một bài viết
    }

    public function delete($id) {
        // Xử lý yêu cầu để xóa một bài viết
    }

    public function view($id) {
        // Xử lý yêu cầu để xem một bài viết
    }
}
?>
